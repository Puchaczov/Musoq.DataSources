﻿using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("Musoq.DataSources.OpenAI.Tests")]